<?php
/*A file to deal with requests regarding users. It will select, delete, and insert into the
user table to make the necessary changes by call.
Willis Kennedy created 12/5 modified through 12/8
*/
$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
if($_SERVER['REQUEST_METHOD'] == 'GET'){
	if(is_null($_SERVER['PATH_INFO'])){
		$result = $mysqli->query("SELECT user FROM users");
		$users = array();
		if($result){
			while($data = $result->fetch_row()){
				$users[] = $data[0];
			}
	}
	header("Content-type: application/json");
	print(json_encode($users));
	exit();
	} else {
		$user = substr($_SERVER['PATH_INFO'], 1);
		if(!is_null($_GET['delete'])){
			$result = $mysqli->query("DELETE FROM users WHERE user='". $user."'");
			return $result;
			header("Content-type: application/json");
			print(json_encode(true));
			exit();
		}
	}
} else if($_SERVER['REQUEST_METHOD'] == 'POST') {
	if(is_null($_SERVER['PATH_INFO'])){
			$result = $mysqli->query("INSERT INTO users (user) VALUES ('$_POST[user]')");
		exit();
	}
}
?>