<!--Form to upload a picture:
Willis Kennedy created 10/2 modified until 11/9-->
<!DOCTYPE html>
<html>
<head>
    <title>Upload a Picture</title>
    <link rel="stylesheet" href= "stylesheet.css">
    <meta charset="utf-8" >
</head>
<body>
 <div class = "header"><h1>Upload A Picture</h1></div>      
	<div id = "wrapper">
	<div class = "content">
		<!--Sends the basic info to insert.php to be processed for upload.-->
	<form class="form" enctype="multipart/form-data" action="insert.php" method="POST" name = "changer">
		<input name="MAX_FILE_SIZE" value = "1000000" type = "hidden">
		Please choose a file: <br><input name="image" accept = "image/jpeg" type="file"><br>
		Please choose some tags:<input name="tags" type ="text"><br><br>
		<input value="Submit" type="submit">
	</form>
	<div>
		<br><br>
	<a href = "index.html" class="button"  data-theme="e">Back Home</a></div> 
	</div>
	</div>
</body>
</html>