<?php
/*A class for individual schedules this makes schedules easy to fetch and run functions on.*/
class Schedule{
	private $id;
	private $active;
	private $user;
	private $image_one;
	private $image_two;
	private $image_three;
	private $image_four;
	private $tags;
	private $type;

	#public static function create($user, $)
	private function __construct($id, $active, $user, $image_one, $image_two, 
		$image_three, $image_four, $tags, $type){
		$this->id = $id;
		$this->active = $active;
		$this->user = $user;
		$this->image_one = $image_one;
		$this->image_two = $image_two;
		$this->image_three = $image_three;
		$this->image_four = $image_four;
		$this->tags = $tags;
		$this->type = $type;
	}

	public static function findByID($id){
		$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
		$result = $mysqli->query("SELECT * FROM tbl_sched WHERE sched_id =". $id);
		if($result){
		if($result->num_rows == 0){
			return null;
		}
		//print('2');
		$schedule_info = $result->fetch_array();
		/*print($schedule_info['user']);
		print($schedule_info['image_four']);
		print($schedule_info['image_one']);
		print($schedule_info['image_two']);
		print($schedule_info['image_three']);
		print($schedule_info['tags']);*/
		return new Schedule(intval($schedule_info['sched_id']),
		 intval($schedule_info['active']), $schedule_info['user'],
		 $schedule_info['image_one'], $schedule_info['image_two'],
		 $schedule_info['image_three'], $schedule_info['image_four'], $schedule_info['tags'],
		 $schedule_info['type']);
		}
		return null;
	}

	public function getFromUser($user){
		$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
		$result = $mysqli->query("SELECT sched_id FROM tbl_sched WHERE user = '" . $user. "' ORDER BY sched_id DESC");
		$schedules = array();
		if($result){
			for($i = 1; $i <= 10; $i++){
				$next_row = $result->fetch_row();
				if($next_row){
					$schedules[] = Schedule::findByID($next_row[0]);
				}
			}
		}
		return $schedules;
	}

	public function getMostActive($user, $active){
		$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
		$result = $mysqli->query("SELECT sched_id FROM tbl_sched WHERE active = ".$active." 
			AND user = '".$user."'ORDER BY sched_id DESC");
		if($result){
			$maxRow = $result->fetch_row();
			if($maxRow){
				$schedule = Schedule::findByID($maxRow[0]);
			}
		}
		return $schedule;
	}



	public function setActive($active){
		$this->active = $active;
		return $this->update();
	}

	public function update(){
		$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
		$queryOne = $mysqli->query("UPDATE tbl_sched SET active = 0 WHERE user = '" .$this->user."' AND active = " .$this->active);
		$result = $mysqli->query("UPDATE tbl_sched SET active = " . $this->active . " WHERE sched_id =" . $this->id);
		return $result;
	}

	public function delete(){
		$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
		$result = $mysqli->query("DELETE FROM tbl_sched WHERE sched_id =" . $this->id);
		return $result;
	}

	public function getJSON(){
		$json_rep = array();
		$json_rep['id'] = $this->id;
		$json_rep['active'] = $this->active;
		$json_rep['user'] = $this->user;
		$json_rep['image_one'] = $this->image_one;
		$json_rep['image_two'] = $this->image_two;
		$json_rep['image_three'] = $this->image_three;
		$json_rep['image_four'] = $this->image_four;
		$json_rep['tags'] = $this->tags;
		$json_rep['type'] = $this->type;
		return $json_rep;
	}

	public function getFromTag($tags, $user){
		$mysqli = new mysqli("mydb5.cs.unc.edu", "ankhar", "fireforge5", "comp523p1db");
		$result = $mysqli->query("SELECT sched_id FROM tbl_sched WHERE tags LIKE '%". $tags . "%'
		 AND user = '".$user."'");
		if($result){
			for($i = 1; $i <= 10; $i++){
				$next_row = $result->fetch_row();
				if($next_row){
					$schedules[] = Schedule::findByID($next_row[0]);
				}
			}
		}
		return $schedules;
	}
}