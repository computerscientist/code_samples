<?php 
  /*This page creates the actual schedule for AdminPictures.php and posts it to the database
  was made before schedules.php and thus used as the primary create option
  Willis Kennedy created 11/9 modified through 11/30*/
        $username = "ankhar";
        $password = "fireforge5";
        $host = "mydb5.cs.unc.edu";
        $database = "comp523p1db";
        mysql_connect($host, $username, $password) or 
        die("Can not connect to database: ".mysql_error());
        mysql_select_db($database) or die("Can not select the database: ". mysql_error());
          $pictures = array();
          $pictures[0] = $_POST['pic1'];
          $pictures[1] = $_POST['pic2'];
          $pictures[2] = $_POST['pic3'];
          $pictures[3] = $_POST['pic4'];
          $tags = mysql_real_escape_string($_POST['tags']);
          mysql_query("INSERT INTO tbl_sched (image_one, image_two, image_three, image_four, user, tags, type) 
            VALUES ('$pictures[0]', '$pictures[1]', '$pictures[2]', '$pictures[3]', '$_POST[user]', '$tags', $_POST[chooseType])
            ") or die(
            "Cannot insert".mysql_error());
            header("Location: http://wwwx.cs.unc.edu/~ankhar/demo2noJqueryMobile/AdminManageSchedule.html");
?>