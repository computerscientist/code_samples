/*function that appends select options onto a select menu with name user
Willis Kennedy created 12/1*/
$(document).ready(function(){
	$.get("readUser.php", function(data){
		$i = 0;
		$.each(data, function(){
			$("select[name='user']").append("<option>" + data[$i] + " </option");
			$i++;
		});
	}, "json");
});