<DOCTYPE html>
	<!--Place to insert uploaded files into the database and relocate uploaded files to web storage.
Willis Kennedy 10/1 modified through 12/7-->
<html lang = "en">
<head>
	<meta charset = "utf-8">
	<title>PHP/MySQL tests</title>
</head>
<body>
	<div id = "wrapper">
		<?php
		/*Inserts information from the form*/
		error_reporting(E_ALL);
		ini_set("display_errors", 1);
		/*You choose the target upload then md5 the file to give it a unique name based on
		the pictures contents. update the target upload to include the full name.*/
		$target = "upload/";
		$filehash = md5_file($_FILES['image']['tmp_name']);
		$name = basename($_FILES['image']['name']);
		$name = str_replace(" ", "_", $name);
		$target = $target . $filehash . $name;
		/*Grab the tags and make the image equal to the name*/
		$image = $filehash . $name;
		$tags = $_POST['tags'];
		/*Connect to mysql and insert the image full name and the tags for later use*/
		$username = "ankhar";
		$password = "fireforge5";
		$host = "mydb5.cs.unc.edu";
		$database = "comp523p1db";
		mysql_connect($host, $username, $password) or 
		die("Can not connect to database: ".mysql_error());
		mysql_select_db($database) or die("Can not select the database: ". mysql_error());

		mysql_query("INSERT INTO tbl_images (image_url) VALUES ('$image')") or die(
			"Cannot insert".mysql_error());
		mysql_query("INSERT INTO tbl_tags (tag_name) VALUES ('$tags')") or die(
			"Cannot insert".mysql_error());
		/*Move the uploaded file to the target location*/
		if(move_uploaded_file($_FILES['image']['tmp_name'], $target))
		{
			/*Redirects you back home after successful upload.*/
			header("Location: http://wwwx.cs.unc.edu/~ankhar/finalPresentation/");
			echo "The file ". $target."has been uploaded,
			and your information has been added to the directory";
		}
		else{
			echo "Sorry, there was a problem uploading your file.";
			echo "<a href = 'http://wwwx.cs.unc.edu/~ankhar/finalPresentation/AdminUploadAPicture.php'>Try again</a>";
		}
		?>
	</div>
</body>
</html>