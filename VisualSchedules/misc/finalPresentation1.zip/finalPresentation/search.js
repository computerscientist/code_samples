$(document).ready(function(){
      $(".search").click(function(){
        /*search.php actually matches by the keyword, and search.js retrieves those matches
        and displays them.
        Willis Kennedy created 10/29 modified through 11/9*/
        $.post("search.php", {keywords: $(".keywords").val()}, function(data){
          $i = 0;
          $("#image_display").empty();
          $.each(data, function(){
            $("#image_display").append("<img src = 'upload/" + data[$i] + "' class = 'images' alt = 'fun'>");
            $i++;
          });
        }, "json");
      });
    });